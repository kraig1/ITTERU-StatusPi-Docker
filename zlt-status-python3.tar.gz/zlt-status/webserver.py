from zlt import webserver

if __name__ == '__main__':
    webserver()
