from zlt import ups_status, sio, nodes

if __name__ == '__main__':
    ups_status(nodes=nodes, sio=sio)
