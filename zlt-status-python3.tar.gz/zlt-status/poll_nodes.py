from zlt import poll_nodes, sio, nodes

if __name__ == '__main__':
    poll_nodes(nodes=nodes, sio=sio)
