from zlt import check_vms, sio, nodes

if __name__ == '__main__':
    check_vms(nodes=nodes, sio=sio)
